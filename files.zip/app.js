/* ===========================================================================
   AIRDRAW — Application Logic
   ---------------------------------------------------------------------------
   Structure:
     1. DOM references & global state
     2. Canvas setup / resize handling
     3. Smoothing engine (One-Euro-style exponential smoothing)
     4. Drawing engine (stroke building, undo/redo via ImageData snapshots)
     5. MediaPipe Hands setup & per-frame landmark processing
     6. Tracker overlay rendering (reticle / fingertip cursor)
     7. UI wiring (toolbar, sliders, swatches, buttons, mobile panel)
     8. Boot sequence (camera permission + MediaPipe init)
   =========================================================================== */

(() => {
  'use strict';

  /* =========================================================================
     1. DOM REFERENCES & GLOBAL STATE
     ========================================================================= */
  const els = {
    bootScreen: document.getElementById('bootScreen'),
    startBtn: document.getElementById('startBtn'),
    bootError: document.getElementById('bootError'),
    app: document.getElementById('app'),

    video: document.getElementById('webcam'),
    drawCanvas: document.getElementById('drawCanvas'),
    trackerCanvas: document.getElementById('trackerCanvas'),
    hiddenCanvas: document.getElementById('hiddenProcessCanvas'),

    statusPill: document.getElementById('statusPill'),
    statusText: document.getElementById('statusText'),
    fpsCounter: document.getElementById('fpsCounter'),
    fullscreenBtn: document.getElementById('fullscreenBtn'),

    modeDraw: document.getElementById('modeDraw'),
    modeErase: document.getElementById('modeErase'),
    colorSwatches: document.getElementById('colorSwatches'),
    customColor: document.getElementById('customColor'),
    brushSize: document.getElementById('brushSize'),
    sizeValue: document.getElementById('sizeValue'),
    smoothing: document.getElementById('smoothing'),
    smoothValue: document.getElementById('smoothValue'),
    undoBtn: document.getElementById('undoBtn'),
    redoBtn: document.getElementById('redoBtn'),
    clearBtn: document.getElementById('clearBtn'),
    saveBtn: document.getElementById('saveBtn'),

    // Mobile
    mModeDraw: document.getElementById('mModeDraw'),
    mModeErase: document.getElementById('mModeErase'),
    mPaletteBtn: document.getElementById('mPaletteBtn'),
    mColorDot: document.getElementById('mColorDot'),
    mUndoBtn: document.getElementById('mUndoBtn'),
    mClearBtn: document.getElementById('mClearBtn'),
    mSaveBtn: document.getElementById('mSaveBtn'),
    mobilePanel: document.getElementById('mobilePanel'),
    mSwatches: document.getElementById('mSwatches'),
    mBrushSize: document.getElementById('mBrushSize'),
    mSizeValue: document.getElementById('mSizeValue'),

    gestureHint: document.getElementById('gestureHint'),
  };

  const drawCtx = els.drawCanvas.getContext('2d', { willReadFrequently: true });
  const trackCtx = els.trackerCanvas.getContext('2d');

  /** Central mutable app state */
  const state = {
    mode: 'draw',              // 'draw' | 'erase'
    color: '#5EEAD4',
    brushSize: 8,
    smoothingAmount: 0.6,      // 0..0.9, higher = smoother/more lag

    isPenDown: false,          // true when index finger is "up" (drawing gesture active)
    handVisible: false,
    lastVisibleAt: 0,

    // Smoothed fingertip position in canvas pixel space
    smoothX: null,
    smoothY: null,
    lastStrokeX: null,
    lastStrokeY: null,

    // Undo/redo stacks of ImageData snapshots
    undoStack: [],
    redoStack: [],
    maxHistory: 30,

    // perf
    lastFrameTime: performance.now(),
    fpsSamples: [],
  };

  /* =========================================================================
     2. CANVAS SETUP / RESIZE
     ========================================================================= */
  function resizeCanvases() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = window.innerWidth;
    const h = window.innerHeight;

    [els.drawCanvas, els.trackerCanvas].forEach((cv) => {
      // Preserve drawing on resize by snapshotting first
      cv.style.width = w + 'px';
      cv.style.height = h + 'px';
    });

    // Snapshot current drawing before resizing the backing store (resizing clears it)
    let snapshot = null;
    if (els.drawCanvas.width > 0 && els.drawCanvas.height > 0) {
      try { snapshot = drawCtx.getImageData(0, 0, els.drawCanvas.width, els.drawCanvas.height); } catch (e) { /* ignore */ }
    }

    els.drawCanvas.width = w * dpr;
    els.drawCanvas.height = h * dpr;
    els.trackerCanvas.width = w * dpr;
    els.trackerCanvas.height = h * dpr;

    drawCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    trackCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawCtx.lineCap = 'round';
    drawCtx.lineJoin = 'round';

    if (snapshot) {
      // best-effort restore (will look stretched on aspect change, acceptable tradeoff)
      const tmp = document.createElement('canvas');
      tmp.width = snapshot.width;
      tmp.height = snapshot.height;
      tmp.getContext('2d').putImageData(snapshot, 0, 0);
      drawCtx.drawImage(tmp, 0, 0, snapshot.width, snapshot.height, 0, 0, w, h);
    }
  }
  window.addEventListener('resize', resizeCanvases);
  window.addEventListener('orientationchange', () => setTimeout(resizeCanvases, 200));

  /* =========================================================================
     3. SMOOTHING ENGINE
     ---------------------------------------------------------------------------
     Exponential moving average with a dynamic alpha: when the finger moves
     fast we trust the new sample more (less lag); when it moves slowly we
     smooth harder (less jitter). This mimics the "One Euro Filter" idea in a
     lightweight form well-suited to per-frame canvas drawing.
     ========================================================================= */
  function smoothPoint(rawX, rawY) {
    if (state.smoothX === null) {
      state.smoothX = rawX;
      state.smoothY = rawY;
      return { x: rawX, y: rawY };
    }

    const dx = rawX - state.smoothX;
    const dy = rawY - state.smoothY;
    const dist = Math.hypot(dx, dy);

    // Base smoothing from user setting, relaxed when movement is large/fast
    const speedFactor = Math.min(dist / 60, 1); // 0 (slow) .. 1 (fast)
    const baseAlpha = 1 - state.smoothingAmount;     // user-controlled responsiveness
    const alpha = Math.min(1, baseAlpha + speedFactor * 0.5);

    state.smoothX += dx * alpha;
    state.smoothY += dy * alpha;

    return { x: state.smoothX, y: state.smoothY };
  }

  function resetSmoothing() {
    state.smoothX = null;
    state.smoothY = null;
    state.lastStrokeX = null;
    state.lastStrokeY = null;
  }

  /* =========================================================================
     4. DRAWING ENGINE
     ========================================================================= */
  function pushHistory() {
    try {
      const snap = drawCtx.getImageData(0, 0, els.drawCanvas.width, els.drawCanvas.height);
      state.undoStack.push(snap);
      if (state.undoStack.length > state.maxHistory) state.undoStack.shift();
      state.redoStack.length = 0;
      updateHistoryButtons();
    } catch (e) { /* ignore (e.g. tainted canvas, shouldn't happen here) */ }
  }

  function strokeStart(x, y) {
    pushHistory();
    state.lastStrokeX = x;
    state.lastStrokeY = y;
    // draw an initial dot so single taps/clicks register as a mark
    drawSegment(x, y, x + 0.01, y + 0.01);
  }

  function drawSegment(x0, y0, x1, y1) {
    drawCtx.save();
    if (state.mode === 'erase') {
      drawCtx.globalCompositeOperation = 'destination-out';
      drawCtx.strokeStyle = 'rgba(0,0,0,1)';
      drawCtx.lineWidth = state.brushSize * 2.2; // eraser feels better a bit larger
    } else {
      drawCtx.globalCompositeOperation = 'source-over';
      drawCtx.strokeStyle = state.color;
      drawCtx.lineWidth = state.brushSize;
      drawCtx.shadowColor = state.color;
      drawCtx.shadowBlur = state.brushSize * 0.6; // soft neon glow, on-brand
    }
    drawCtx.beginPath();
    drawCtx.moveTo(x0, y0);
    drawCtx.lineTo(x1, y1);
    drawCtx.stroke();
    drawCtx.restore();
  }

  function strokeTo(x, y) {
    if (state.lastStrokeX === null) {
      strokeStart(x, y);
      return;
    }
    drawSegment(state.lastStrokeX, state.lastStrokeY, x, y);
    state.lastStrokeX = x;
    state.lastStrokeY = y;
  }

  function strokeEnd() {
    state.lastStrokeX = null;
    state.lastStrokeY = null;
  }

  function clearCanvas(recordHistory = true) {
    if (recordHistory) pushHistory();
    drawCtx.clearRect(0, 0, els.drawCanvas.width, els.drawCanvas.height);
  }

  function undo() {
    if (state.undoStack.length === 0) return;
    const current = drawCtx.getImageData(0, 0, els.drawCanvas.width, els.drawCanvas.height);
    state.redoStack.push(current);
    const prev = state.undoStack.pop();
    drawCtx.putImageData(prev, 0, 0);
    updateHistoryButtons();
  }

  function redo() {
    if (state.redoStack.length === 0) return;
    const current = drawCtx.getImageData(0, 0, els.drawCanvas.width, els.drawCanvas.height);
    state.undoStack.push(current);
    const next = state.redoStack.pop();
    drawCtx.putImageData(next, 0, 0);
    updateHistoryButtons();
  }

  function updateHistoryButtons() {
    const canUndo = state.undoStack.length > 0;
    const canRedo = state.redoStack.length > 0;
    [els.undoBtn, els.mUndoBtn].forEach(b => b && (b.disabled = !canUndo));
    if (els.redoBtn) els.redoBtn.disabled = !canRedo;
  }

  function savePNG() {
    // Composite the camera frame (mirrored) + drawing into one export canvas
    const w = els.drawCanvas.width;
    const h = els.drawCanvas.height;
    const out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    const octx = out.getContext('2d');

    // Background: dark void so transparent eraser areas look intentional
    octx.fillStyle = '#08090C';
    octx.fillRect(0, 0, w, h);

    octx.drawImage(els.drawCanvas, 0, 0);

    const link = document.createElement('a');
    const ts = new Date().toISOString().replace(/[:.]/g, '-');
    link.download = `airdraw-${ts}.png`;
    link.href = out.toDataURL('image/png');
    link.click();
  }

  /* =========================================================================
     5. MEDIAPIPE HANDS SETUP
     ========================================================================= */
  let hands = null;
  let mpCamera = null;

  // MediaPipe landmark indices we care about
  const LM = {
    WRIST: 0,
    THUMB_TIP: 4,
    INDEX_MCP: 5,
    INDEX_PIP: 6,
    INDEX_DIP: 7,
    INDEX_TIP: 8,
    MIDDLE_MCP: 9,
    MIDDLE_TIP: 12,
    RING_TIP: 16,
    PINKY_TIP: 20,
  };

  /**
   * Determine whether the index finger is extended ("pen down") by comparing
   * the tip's distance from the palm against the middle knuckle's distance —
   * a simple, fast heuristic that works across hand orientations without
   * needing 3D depth reasoning.
   */
  function isIndexExtended(lm) {
    const wrist = lm[LM.WRIST];
    const tip = lm[LM.INDEX_TIP];
    const pip = lm[LM.INDEX_PIP];
    const mcp = lm[LM.INDEX_MCP];

    const dTip = Math.hypot(tip.x - wrist.x, tip.y - wrist.y);
    const dPip = Math.hypot(pip.x - wrist.x, pip.y - wrist.y);
    const dMcp = Math.hypot(mcp.x - wrist.x, mcp.y - wrist.y);

    // Extended if tip is meaningfully farther from wrist than the lower joints
    return dTip > dPip && dTip > dMcp * 1.18;
  }

  /** True if other fingers (middle/ring/pinky) are curled, to avoid open-palm false positives */
  function areOthersCurled(lm) {
    const wrist = lm[LM.WRIST];
    const checks = [
      [LM.MIDDLE_TIP, 10],
      [LM.RING_TIP, 14],
      [LM.PINKY_TIP, 18],
    ];
    let curled = 0;
    checks.forEach(([tipIdx, pipIdx]) => {
      const tip = lm[tipIdx];
      const pip = lm[pipIdx];
      const dTip = Math.hypot(tip.x - wrist.x, tip.y - wrist.y);
      const dPip = Math.hypot(pip.x - wrist.x, pip.y - wrist.y);
      if (dTip < dPip * 1.05) curled++;
    });
    return curled >= 2; // majority curled = fist-ish / pointing gesture
  }

  function onHandsResults(results) {
    const now = performance.now();
    trackFps(now);

    const w = window.innerWidth;
    const h = window.innerHeight;

    if (!results.multiHandLandmarks || results.multiHandLandmarks.length === 0) {
      handleHandLost(now);
      renderTracker(null, false);
      return;
    }

    const lm = results.multiHandLandmarks[0];
    state.handVisible = true;
    state.lastVisibleAt = now;
    setStatus('tracking', 'Hand tracked');

    // Mirror X because the video element is CSS-mirrored for a natural feel
    const rawX = (1 - lm[LM.INDEX_TIP].x) * w;
    const rawY = lm[LM.INDEX_TIP].y * h;

    const smoothed = smoothPoint(rawX, rawY);

    const extended = isIndexExtended(lm);
    const othersCurled = areOthersCurled(lm);
    const penShouldBeDown = extended && othersCurled;

    if (penShouldBeDown && !state.isPenDown) {
      // Pen just touched down
      state.isPenDown = true;
      strokeStart(smoothed.x, smoothed.y);
    } else if (penShouldBeDown && state.isPenDown) {
      strokeTo(smoothed.x, smoothed.y);
    } else if (!penShouldBeDown && state.isPenDown) {
      // Pen lifted
      state.isPenDown = false;
      strokeEnd();
    }

    renderTracker(smoothed, penShouldBeDown);
  }

  function handleHandLost(now) {
    if (state.handVisible && now - state.lastVisibleAt > 350) {
      state.handVisible = false;
      setStatus('lost', 'Hand lost — show it to the camera');
      if (state.isPenDown) {
        state.isPenDown = false;
        strokeEnd();
      }
      resetSmoothing();
    } else if (!state.handVisible) {
      setStatus('searching', 'Searching for hand…');
    }
  }

  /* =========================================================================
     6. TRACKER OVERLAY (reticle / fingertip cursor) — the signature element
     ========================================================================= */
  let reticlePulse = 0;

  function renderTracker(point, isDown) {
    const w = window.innerWidth;
    const h = window.innerHeight;
    trackCtx.clearRect(0, 0, w, h);
    if (!point) return;

    reticlePulse += 0.12;
    const pulse = (Math.sin(reticlePulse) + 1) / 2; // 0..1

    const baseColor = state.mode === 'erase' ? '#FB7185' : state.color;
    const r = isDown ? 14 + pulse * 2 : 18 + pulse * 3;

    trackCtx.save();
    trackCtx.translate(point.x, point.y);

    // Outer ring
    trackCtx.beginPath();
    trackCtx.arc(0, 0, r, 0, Math.PI * 2);
    trackCtx.strokeStyle = isDown ? baseColor : 'rgba(255,255,255,0.6)';
    trackCtx.lineWidth = isDown ? 2.5 : 1.5;
    trackCtx.globalAlpha = isDown ? 0.9 : 0.55;
    trackCtx.stroke();

    // Crosshair ticks
    const tickLen = 6;
    const tickGap = r + 4;
    trackCtx.globalAlpha = isDown ? 0.85 : 0.4;
    trackCtx.lineWidth = 1.5;
    [0, 90, 180, 270].forEach((deg) => {
      const rad = (deg * Math.PI) / 180;
      const x1 = Math.cos(rad) * tickGap;
      const y1 = Math.sin(rad) * tickGap;
      const x2 = Math.cos(rad) * (tickGap + tickLen);
      const y2 = Math.sin(rad) * (tickGap + tickLen);
      trackCtx.beginPath();
      trackCtx.moveTo(x1, y1);
      trackCtx.lineTo(x2, y2);
      trackCtx.strokeStyle = baseColor;
      trackCtx.stroke();
    });

    // Center dot
    trackCtx.beginPath();
    trackCtx.arc(0, 0, isDown ? 4.5 : 3, 0, Math.PI * 2);
    trackCtx.fillStyle = baseColor;
    trackCtx.globalAlpha = 1;
    trackCtx.shadowColor = baseColor;
    trackCtx.shadowBlur = isDown ? 14 : 6;
    trackCtx.fill();

    trackCtx.restore();
  }

  /* =========================================================================
     7. STATUS / FPS HELPERS
     ========================================================================= */
  function setStatus(kind, text) {
    els.statusPill.classList.remove('status-searching', 'status-tracking', 'status-lost');
    els.statusPill.classList.add(`status-${kind}`);
    els.statusText.textContent = text;
  }

  function trackFps(now) {
    const dt = now - state.lastFrameTime;
    state.lastFrameTime = now;
    if (dt <= 0) return;
    const fps = 1000 / dt;
    state.fpsSamples.push(fps);
    if (state.fpsSamples.length > 20) state.fpsSamples.shift();
    const avg = state.fpsSamples.reduce((a, b) => a + b, 0) / state.fpsSamples.length;
    els.fpsCounter.textContent = `${Math.round(avg)} FPS`;
  }

  /* =========================================================================
     8. UI WIRING
     ========================================================================= */
  function setMode(mode) {
    state.mode = mode;
    [els.modeDraw, els.modeErase].forEach(b => b.classList.remove('active'));
    [els.mModeDraw, els.mModeErase].forEach(b => b.classList.remove('active'));
    if (mode === 'draw') {
      els.modeDraw.classList.add('active');
      els.mModeDraw.classList.add('active');
    } else {
      els.modeErase.classList.add('active');
      els.mModeErase.classList.add('active');
    }
  }

  function setColor(hex) {
    state.color = hex;
    document.querySelectorAll('.swatch[data-color]').forEach(s => {
      s.classList.toggle('active', s.dataset.color.toLowerCase() === hex.toLowerCase());
    });
    els.mColorDot.style.background = hex;
    // switching color implies intent to draw
    if (state.mode !== 'draw') {
      setMode('draw');
    }
  }

  function buildMobileSwatches() {
    const colors = ['#5EEAD4', '#38BDF8', '#A78BFA', '#FB7185', '#FBBF24', '#F8FAFC'];
    els.mSwatches.innerHTML = '';
    colors.forEach(c => {
      const b = document.createElement('button');
      b.className = 'swatch';
      b.style.setProperty('--c', c);
      b.dataset.color = c;
      if (c.toLowerCase() === state.color.toLowerCase()) b.classList.add('active');
      b.addEventListener('click', () => {
        setColor(c);
        buildMobileSwatches();
      });
      els.mSwatches.appendChild(b);
    });
  }

  function wireUI() {
    // Mode (desktop)
    els.modeDraw.addEventListener('click', () => setMode('draw'));
    els.modeErase.addEventListener('click', () => setMode('erase'));
    // Mode (mobile)
    els.mModeDraw.addEventListener('click', () => setMode('draw'));
    els.mModeErase.addEventListener('click', () => setMode('erase'));

    // Colors (desktop)
    els.colorSwatches.querySelectorAll('.swatch[data-color]').forEach(s => {
      s.addEventListener('click', () => setColor(s.dataset.color));
    });
    els.customColor.addEventListener('input', (e) => setColor(e.target.value));

    // Brush size (desktop + mobile kept in sync)
    els.brushSize.addEventListener('input', (e) => {
      state.brushSize = Number(e.target.value);
      els.sizeValue.textContent = state.brushSize;
      els.mBrushSize.value = state.brushSize;
      els.mSizeValue.textContent = state.brushSize;
    });
    els.mBrushSize.addEventListener('input', (e) => {
      state.brushSize = Number(e.target.value);
      els.mSizeValue.textContent = state.brushSize;
      els.brushSize.value = state.brushSize;
      els.sizeValue.textContent = state.brushSize;
    });

    // Smoothing
    els.smoothing.addEventListener('input', (e) => {
      const v = Number(e.target.value);
      state.smoothingAmount = v / 100;
      els.smoothValue.textContent = `${v}%`;
    });

    // History
    els.undoBtn.addEventListener('click', undo);
    els.redoBtn.addEventListener('click', redo);
    els.mUndoBtn.addEventListener('click', undo);

    // Clear / Save
    els.clearBtn.addEventListener('click', () => clearCanvas(true));
    els.mClearBtn.addEventListener('click', () => clearCanvas(true));
    els.saveBtn.addEventListener('click', savePNG);
    els.mSaveBtn.addEventListener('click', savePNG);

    // Fullscreen
    els.fullscreenBtn.addEventListener('click', toggleFullscreen);

    // Mobile palette toggle
    els.mPaletteBtn.addEventListener('click', () => {
      const isHidden = els.mobilePanel.hasAttribute('hidden');
      if (isHidden) {
        els.mobilePanel.removeAttribute('hidden');
      } else {
        els.mobilePanel.setAttribute('hidden', '');
      }
    });

    // Keyboard shortcuts (desktop convenience)
    window.addEventListener('keydown', (e) => {
      const ctrl = e.ctrlKey || e.metaKey;
      if (ctrl && e.key.toLowerCase() === 'z' && !e.shiftKey) { e.preventDefault(); undo(); }
      else if (ctrl && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) { e.preventDefault(); redo(); }
      else if (e.key.toLowerCase() === 'e') setMode('erase');
      else if (e.key.toLowerCase() === 'b' || e.key.toLowerCase() === 'p') setMode('draw');
      else if (e.key.toLowerCase() === 'c' && ctrl === false) clearCanvas(true);
      else if (e.key === '[') { state.brushSize = Math.max(2, state.brushSize - 2); syncBrushUI(); }
      else if (e.key === ']') { state.brushSize = Math.min(48, state.brushSize + 2); syncBrushUI(); }
    });

    buildMobileSwatches();
  }

  function syncBrushUI() {
    els.brushSize.value = state.brushSize;
    els.sizeValue.textContent = state.brushSize;
    els.mBrushSize.value = state.brushSize;
    els.mSizeValue.textContent = state.brushSize;
  }

  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  }

  /* =========================================================================
     9. BOOT SEQUENCE — camera permission + MediaPipe init
     ========================================================================= */
  async function startApp() {
    els.startBtn.disabled = true;
    els.startBtn.textContent = 'Requesting camera…';
    hideBootError();

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      els.video.srcObject = stream;
      await new Promise((resolve) => {
        els.video.onloadedmetadata = () => resolve();
      });
      await els.video.play();

      // Reveal app shell, hide boot screen
      els.bootScreen.style.opacity = '0';
      els.bootScreen.style.transition = 'opacity 0.4s ease';
      setTimeout(() => { els.bootScreen.hidden = true; }, 420);
      els.app.hidden = false;

      resizeCanvases();
      wireUI();
      initMediaPipe();

      // Auto-dismiss gesture hint after its CSS animation completes
      setTimeout(() => { els.gestureHint.style.display = 'none'; }, 6200);

    } catch (err) {
      console.error('Camera init failed:', err);
      showBootError(describeError(err));
      els.startBtn.disabled = false;
      els.startBtn.textContent = 'Try again';
    }
  }

  function describeError(err) {
    if (err && err.name === 'NotAllowedError') {
      return 'Camera access was denied. Please allow camera permissions in your browser settings and try again.';
    }
    if (err && err.name === 'NotFoundError') {
      return 'No camera was found on this device.';
    }
    if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
      return 'Camera access requires HTTPS. Please open this app over a secure connection.';
    }
    return 'Could not access the camera. Please check your browser permissions and try again.';
  }

  function showBootError(msg) {
    els.bootError.textContent = msg;
    els.bootError.hidden = false;
  }
  function hideBootError() {
    els.bootError.hidden = true;
  }

  function initMediaPipe() {
    hands = new Hands({
      locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
    });

    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 1,
      minDetectionConfidence: 0.7,
      minTrackingConfidence: 0.6,
    });

    hands.onResults(onHandsResults);

    mpCamera = new Camera(els.video, {
      onFrame: async () => {
        try {
          await hands.send({ image: els.video });
        } catch (e) {
          // transient frame errors can happen during resize/tab-switch; ignore
        }
      },
      width: 1280,
      height: 720,
    });

    mpCamera.start().catch((err) => {
      console.error('MediaPipe camera start failed:', err);
      setStatus('lost', 'Tracking failed to start');
    });
  }

  els.startBtn.addEventListener('click', startApp);

  // Pause/resume gracefully when tab is hidden, to save battery/CPU
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (state.isPenDown) { state.isPenDown = false; strokeEnd(); }
    }
  });

})();
